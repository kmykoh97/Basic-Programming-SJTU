If using g++ compiler, run:
> g++ main.cpp calculation.cpp tokenStream.cpp extra.cpp -o calculator.exe

If using MakeFile, run:
> make

Calculator by c++
Meng Yit Koh
517030990022
Shanghai Jiao Tong University
2018